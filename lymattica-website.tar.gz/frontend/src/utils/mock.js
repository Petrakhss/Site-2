// Mock data for the Lymattica website
// This file contains all mock data used throughout the application
// In production, this would be replaced with actual API calls

export const mockData = {
  // Company information
  company: {
    name: "Lymattica",
    location: "Athens, Greece",
    established: "2008",
    slogan: "Επαγγελματικές Υπηρεσίες Διαχείρισης Αποβλήτων"
  },

  // Contact information
  contact: {
    phones: {
      main: "210 123 4567",
      emergency: "694 567 8901"
    },
    emails: {
      info: "info@lymattica.gr",
      emergency: "emergency@lymattica.gr"
    },
    address: {
      city: "Athens",
      region: "Attica",
      country: "Greece"
    },
    hours: {
      regular: "Monday-Friday: 8:00-18:00",
      emergency: "24/7 Available"
    }
  },

  // Services offered
  services: {
    sewage: {
      title: "Αποχέτευση & Καθαρισμός",
      description: "Professional sewage cleaning and maintenance services",
      features: [
        "Pipe unblocking",
        "Manhole cleaning", 
        "Network maintenance"
      ],
      availability: "24/7",
      responseTime: "30 minutes"
    },
    pumping: {
      title: "Άντληση Νερού",
      description: "Water pumping from basements and flooded areas",
      features: [
        "Basement pumping",
        "Flood cleanup",
        "Emergency interventions"
      ],
      availability: "24/7",
      responseTime: "15 minutes"
    },
    waste: {
      title: "Μεταφορά Αποβλήτων",
      description: "Safe and environmentally responsible waste transport",
      features: [
        "Liquid waste",
        "Industrial waste",
        "Legal disposal"
      ],
      availability: "Business hours",
      responseTime: "Same day"
    }
  },

  // Statistics
  stats: {
    experience: "15+",
    clients: "500+",
    availability: "24/7",
    satisfaction: "100%"
  },

  // Testimonials (mock customer feedback)
  testimonials: [
    {
      id: 1,
      name: "Μαρία Παπαδοπούλου",
      location: "Κολωνάκι, Αθήνα",
      service: "Άντληση Νερού",
      rating: 5,
      comment: "Εξαιρετική εξυπηρέτηση! Ήρθαν αμέσως και λύσανε το πρόβλημα πλημμύρας στο κελάρι μας.",
      date: "2024-01-15"
    },
    {
      id: 2,
      name: "Γιάννης Κωνσταντίνου",
      location: "Κυψέλη, Αθήνα",
      service: "Αποχέτευση",
      rating: 5,
      comment: "Πολύ επαγγελματική ομάδα. Καθάρισαν την απόφραξη γρήγορα και καθαρά.",
      date: "2024-01-10"
    }
  ],

  // FAQ
  faq: [
    {
      id: 1,
      question: "Πόσο γρήγορα μπορείτε να ανταποκριθείτε σε έκτακτη ανάγκη;",
      answer: "Για έκτακτες ανάγκες, μπορούμε να φτάσουμε στην τοποθεσία σας εντός 15-30 λεπτών, ανάλογα με την περιοχή."
    },
    {
      id: 2,
      question: "Εργάζεστε Σαββατοκύριακα;",
      answer: "Ναι, είμαστε διαθέσιμοι 24/7 για έκτακτες ανάγκες. Για προγραμματισμένες εργασίες, εργαζόμαστε Δευτέρα-Παρασκευή 8:00-18:00."
    },
    {
      id: 3,
      question: "Τι περιοχές εξυπηρετείτε;",
      answer: "Εξυπηρετούμε όλη την Αθήνα και την ευρύτερη περιοχή της Αττικής. Για πιο μακρινές περιοχές, επικοινωνήστε μαζί μας για διαθεσιμότητα."
    },
    {
      id: 4,
      question: "Παρέχετε εγγύηση για τις εργασίες σας;",
      answer: "Ναι, όλες οι εργασίες μας καλύπτονται από εγγύηση. Η διάρκεια εξαρτάται από τον τύπο της υπηρεσίας."
    }
  ],

  // Form submissions (simulated storage)
  contactSubmissions: [],

  // Emergency procedures
  emergency: {
    steps: [
      "Καλέστε το 694 567 8901",
      "Περιγράψτε το πρόβλημα",
      "Παράσχετε τη διεύθυνση",
      "Περιμένετε την άφιξη της ομάδας"
    ],
    averageResponseTime: "20 minutes",
    coverage: "Athens & Attica region"
  }
};

// Helper functions for mock data operations
export const mockHelpers = {
  // Simulate API delay
  delay: (ms = 1000) => new Promise(resolve => setTimeout(resolve, ms)),
  
  // Add contact submission
  addContactSubmission: (submission) => {
    const submissions = JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
    const newSubmission = {
      id: Date.now(),
      ...submission,
      timestamp: new Date().toISOString()
    };
    submissions.push(newSubmission);
    localStorage.setItem('contactSubmissions', JSON.stringify(submissions));
    return newSubmission;
  },
  
  // Get contact submissions
  getContactSubmissions: () => {
    return JSON.parse(localStorage.getItem('contactSubmissions') || '[]');
  },
  
  // Simulate form validation
  validateContactForm: (data) => {
    const errors = {};
    
    if (!data.name || data.name.length < 2) {
      errors.name = "Το όνομα είναι απαραίτητο";
    }
    
    if (!data.email || !data.email.includes('@')) {
      errors.email = "Παρακαλώ εισάγετε έγκυρο email";
    }
    
    if (!data.phone || data.phone.length < 10) {
      errors.phone = "Παρακαλώ εισάγετε έγκυρο τηλέφωνο";
    }
    
    if (!data.message || data.message.length < 10) {
      errors.message = "Το μήνυμα πρέπει να έχει τουλάχιστον 10 χαρακτήρες";
    }
    
    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }
};

export default mockData;