import React from "react";
import { Phone, Mail, MapPin, Clock } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const services = [
    "Αποχέτευση & Καθαρισμός",
    "Άντληση Νερού",
    "Μεταφορά Αποβλήτων",
    "Έκτακτες Παρεμβάσεις"
  ];

  const quickLinks = [
    { name: "Αρχική", href: "#home" },
    { name: "Υπηρεσίες", href: "#services" },
    { name: "Σχετικά", href: "#about" },
    { name: "Επικοινωνία", href: "#contact" }
  ];

  return (
    <footer className="bg-text-primary text-white py-16">
      <div className="container">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          
          {/* Company Info */}
          <div>
            <h3 className="text-2xl font-bold mb-4 text-brand-green">LYMATTICA</h3>
            <p className="body-md text-gray-300 mb-6">
              Επαγγελματικές υπηρεσίες διαχείρισης αποβλήτων και αποχέτευσης 
              στην Αθήνα και την ευρύτερη περιοχή.
            </p>
            <div className="flex items-center text-gray-300 mb-2">
              <MapPin className="w-4 h-4 mr-2 flex-shrink-0" />
              <span className="body-sm">Αθήνα, Αττική</span>
            </div>
            <div className="flex items-center text-gray-300">
              <Clock className="w-4 h-4 mr-2 flex-shrink-0" />
              <span className="body-sm">24/7 Διαθεσιμότητα</span>
            </div>
          </div>

          {/* Services */}
          <div>
            <h4 className="heading-4 text-white mb-6">Υπηρεσίες</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
                  <a href="#services" className="body-sm text-gray-300 hover:text-brand-green transition-colors">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="heading-4 text-white mb-6">Γρήγοροι Σύνδεσμοι</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href={link.href} 
                    className="body-sm text-gray-300 hover:text-brand-green transition-colors"
                  >
                    {link.name}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="heading-4 text-white mb-6">Επικοινωνία</h4>
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Phone className="w-5 h-5 text-brand-orange mt-0.5 flex-shrink-0" />
                <div>
                  <a href="tel:+302101234567" className="body-sm text-gray-300 hover:text-white transition-colors block">
                    210 123 4567
                  </a>
                  <a href="tel:+306945678901" className="body-sm text-gray-300 hover:text-white transition-colors">
                    694 567 8901
                  </a>
                </div>
              </div>
              
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-brand-orange flex-shrink-0" />
                <a 
                  href="mailto:info@lymattica.gr" 
                  className="body-sm text-gray-300 hover:text-white transition-colors"
                >
                  info@lymattica.gr
                </a>
              </div>
            </div>

            {/* Emergency Call Button */}
            <div className="mt-6">
              <a 
                href="tel:+306945678901" 
                className="bg-brand-orange hover:bg-orange-hover text-white px-4 py-2 rounded-lg text-sm font-medium transition-colors inline-flex items-center"
              >
                <Phone className="w-4 h-4 mr-2" />
                Έκτακτη Ανάγκη
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="border-t border-gray-700 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="body-sm text-gray-400">
              © {currentYear} Lymattica. Όλα τα δικαιώματα κατοχυρωμένα.
            </p>
            <div className="flex gap-6">
              <a href="#" className="body-sm text-gray-400 hover:text-white transition-colors">
                Όροι Χρήσης
              </a>
              <a href="#" className="body-sm text-gray-400 hover:text-white transition-colors">
                Πολιτική Απορρήτου
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;