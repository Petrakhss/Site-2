import React from "react";
import { MapPin, Award, Users, Clock } from "lucide-react";

const About = () => {
  const stats = [
    { number: "15+", label: "Χρόνια Εμπειρίας", icon: <Clock className="w-6 h-6 text-brand-orange" /> },
    { number: "500+", label: "Ικανοποιημένοι Πελάτες", icon: <Users className="w-6 h-6 text-brand-orange" /> },
    { number: "24/7", label: "Διαθεσιμότητα", icon: <Award className="w-6 h-6 text-brand-orange" /> },
    { number: "100%", label: "Επαγγελματισμός", icon: <MapPin className="w-6 h-6 text-brand-orange" /> }
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Content */}
          <div>
            <h2 className="heading-1 text-text-primary mb-6">
              Σχετικά με τη 
              <span className="text-brand-green"> Lymattica</span>
            </h2>
            
            <div className="space-y-6">
              <p className="body-lg text-text-secondary">
                Η Lymattica είναι μια κορυφαία εταιρεία στον τομέα της διαχείρισης αποβλήτων 
                και υδρολογικών υπηρεσιών, που εξυπηρετεί την Αθήνα και την ευρύτερη περιοχή 
                εδώ και πάνω από 15 χρόνια.
              </p>
              
              <p className="body-md text-text-secondary">
                Με έδρα την Αθήνα, η ομάδα μας αποτελείται από έμπειρους τεχνικούς που 
                διαθέτουν την απαραίτητη εκπαίδευση και πιστοποιήσεις για την παροχή 
                υψηλής ποιότητας υπηρεσιών.
              </p>

              <div className="bg-bg-subtle rounded-lg p-6">
                <h3 className="heading-4 text-text-primary mb-4">Η Αποστολή μας</h3>
                <p className="body-md text-text-secondary">
                  Να παρέχουμε αξιόπιστες, γρήγορες και περιβαλλοντικά υπεύθυνες 
                  λύσεις για όλες τις ανάγκες διαχείρισης αποβλήτων και υδρολογικών 
                  προβλημάτων των πελατών μας.
                </p>
              </div>
            </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <div key={index} className="design-card text-center hover-lift">
                <div className="w-16 h-16 bg-bg-subtle rounded-2xl flex items-center justify-center mx-auto mb-4">
                  {stat.icon}
                </div>
                <div className="display-md text-brand-green mb-2">{stat.number}</div>
                <div className="body-md text-text-secondary">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Values Section */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h3 className="heading-2 text-text-primary mb-4">Οι Αξίες μας</h3>
            <p className="body-lg text-text-secondary max-w-2xl mx-auto">
              Οι αξίες που μας καθοδηγούν στην καθημερινή μας δουλειά
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-20 h-20 bg-brand-green rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Award className="w-10 h-10 text-white" />
              </div>
              <h4 className="heading-4 text-text-primary mb-4">Ποιότητα</h4>
              <p className="body-md text-text-secondary">
                Χρησιμοποιούμε τον καλύτερο εξοπλισμό και τις πιο σύγχρονες τεχνικές 
                για να εξασφαλίσουμε άριστα αποτελέσματα.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-brand-green rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Clock className="w-10 h-10 text-white" />
              </div>
              <h4 className="heading-4 text-text-primary mb-4">Ταχύτητα</h4>
              <p className="body-md text-text-secondary">
                Κατανοούμε ότι τα προβλήματα αποχέτευσης και αποβλήτων χρειάζονται 
                άμεση αντιμετώπιση. Είμαστε πάντα έτοιμοι.
              </p>
            </div>

            <div className="text-center">
              <div className="w-20 h-20 bg-brand-green rounded-2xl flex items-center justify-center mx-auto mb-6">
                <Users className="w-10 h-10 text-white" />
              </div>
              <h4 className="heading-4 text-text-primary mb-4">Αξιοπιστία</h4>
              <p className="body-md text-text-secondary">
                Η εμπιστοσύνη των πελατών μας είναι το πιο πολύτιμο κεφάλαιό μας. 
                Τηρούμε πάντα τις δεσμεύσεις μας.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;