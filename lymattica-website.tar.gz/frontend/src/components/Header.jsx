import React, { useState } from "react";
import { Menu, X, Phone, Mail } from "lucide-react";
import { Link, useLocation } from "react-router-dom";

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const location = useLocation();

  const navigation = [
    { name: "Αρχική", href: "/" },
    { name: "Υπηρεσίες", href: "/services" },
    { name: "Σχετικά", href: "/#about" },
    { name: "Επικοινωνία", href: "/#contact" }
  ];

  const handleNavClick = (href) => {
    setIsMenuOpen(false);
    
    // Handle home navigation - scroll to top
    if (href === '/' && location.pathname === '/') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    
    // Handle hash navigation for home page sections
    if (href.startsWith('/#') && location.pathname === '/') {
      const element = document.querySelector(href.substring(1));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  return (
    <header className="design-header">
      <div className="nav-container">
        {/* Logo */}
        <div className="flex items-center">
          <Link to="/" className="flex items-center space-x-3">
            <img 
              src="https://images.unsplash.com/photo-1604187351574-c75ca79f5807?w=40&h=40&fit=crop&crop=center" 
              alt="Lymattica Logo" 
              className="w-10 h-10 rounded-lg object-cover"
            />
            <h1 className="text-2xl font-bold text-brand-green">
              LYMATTICA
            </h1>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <nav className="nav-menu hidden md:flex">
          {navigation.map((item) => (
            item.href.startsWith('/#') ? (
              <a
                key={item.name}
                href={item.href}
                className="nav-link"
                onClick={(e) => {
                  if (location.pathname === '/') {
                    e.preventDefault();
                    handleNavClick(item.href);
                  }
                }}
              >
                {item.name}
              </a>
            ) : (
              <Link
                key={item.name}
                to={item.href}
                className="nav-link"
                onClick={(e) => {
                  if (item.href === '/' && location.pathname === '/') {
                    e.preventDefault();
                    handleNavClick(item.href);
                  }
                }}
              >
                {item.name}
              </Link>
            )
          ))}
          <div className="flex items-center gap-4 ml-8">
            <a href="tel:+302101234567" className="flex items-center text-brand-green hover:text-green-hover transition-colors">
              <Phone className="w-4 h-4 mr-2" />
              <span className="text-sm font-medium">210 123 4567</span>
            </a>
          </div>
        </nav>

        {/* Mobile menu button */}
        <button
          className="btn-nav-toggle md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <X className="w-5 h-5 text-white" /> : <Menu className="w-5 h-5 text-white" />}
        </button>
      </div>

      {/* Mobile Navigation */}
      {isMenuOpen && (
        <div className="md:hidden bg-white border-t border-border-light">
          <div className="container py-4">
            {navigation.map((item) => (
              item.href.startsWith('/#') ? (
                <a
                  key={item.name}
                  href={item.href}
                  className="block py-3 text-text-primary hover:text-brand-green transition-colors"
                  onClick={(e) => {
                    if (location.pathname === '/') {
                      e.preventDefault();
                      handleNavClick(item.href);
                    } else {
                      setIsMenuOpen(false);
                    }
                  }}
                >
                  {item.name}
                </a>
              ) : (
                <Link
                  key={item.name}
                  to={item.href}
                  className="block py-3 text-text-primary hover:text-brand-green transition-colors"
                  onClick={(e) => {
                    if (item.href === '/' && location.pathname === '/') {
                      e.preventDefault();
                      handleNavClick(item.href);
                    } else {
                      setIsMenuOpen(false);
                    }
                  }}
                >
                  {item.name}
                </Link>
              )
            ))}
            <div className="pt-4 border-t border-border-light mt-4">
              <a href="tel:+302101234567" className="flex items-center text-brand-green">
                <Phone className="w-4 h-4 mr-2" />
                <span>210 123 4567</span>
              </a>
              <a href="mailto:info@lymattica.gr" className="flex items-center text-brand-green mt-2">
                <Mail className="w-4 h-4 mr-2" />
                <span>info@lymattica.gr</span>
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;