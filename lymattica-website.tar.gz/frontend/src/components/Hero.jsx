import React from "react";
import { ArrowRight, CheckCircle } from "lucide-react";

const Hero = () => {
  return (
    <section id="home" className="hero-section">
      <div className="section-container">
        <div className="text-center max-w-4xl mx-auto">
          <h1 className="display-lg text-text-primary mb-6">
            Επαγγελματικές Υπηρεσίες
            <br />
            <span className="text-brand-green">Διαχείρισης Αποβλήτων</span>
          </h1>
          
          <p className="body-xl text-text-secondary mb-8 max-w-2xl mx-auto">
            Η Lymattica παρέχει αξιόπιστες υπηρεσίες αποχέτευσης, άντλησης νερού και 
            μεταφοράς αποβλήτων στη περιοχή της Αθήνας με επαγγελματισμό και ταχύτητα.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <button className="btn-primary">
              Επικοινωνήστε Τώρα
              <ArrowRight className="w-5 h-5 ml-2" />
            </button>
            <button className="btn-secondary">
              Δείτε τις Υπηρεσίες μας
            </button>
          </div>

          {/* Trust Indicators */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
            <div className="flex items-center justify-center gap-3">
              <CheckCircle className="w-6 h-6 text-brand-green flex-shrink-0" />
              <span className="body-md text-text-secondary">24/7 Διαθεσιμότητα</span>
            </div>
            <div className="flex items-center justify-center gap-3">
              <CheckCircle className="w-6 h-6 text-brand-green flex-shrink-0" />
              <span className="body-md text-text-secondary">Πιστοποιημένοι Τεχνικοί</span>
            </div>
            <div className="flex items-center justify-center gap-3">
              <CheckCircle className="w-6 h-6 text-brand-green flex-shrink-0" />
              <span className="body-md text-text-secondary">Γρήγορη Ανταπόκριση</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;