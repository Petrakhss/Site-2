import React, { useState } from "react";
import { Phone, Mail, MapPin, Clock, Send, CheckCircle, AlertCircle } from "lucide-react";
import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Contact = () => {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "",
    message: ""
  });

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState(null); // 'success', 'error', or null

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);

    try {
      const response = await axios.post(`${API}/contacts`, formData);
      
      if (response.data.success) {
        setSubmitStatus('success');
        setFormData({
          name: "",
          email: "",
          phone: "",
          service: "",
          message: ""
        });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      console.error('Error submitting contact form:', error);
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const contactInfo = [
    {
      icon: <Phone className="w-6 h-6 text-brand-orange" />,
      title: "Τηλέφωνο",
      details: ["210 123 4567", "694 567 8901"],
      action: "tel:+302101234567"
    },
    {
      icon: <Mail className="w-6 h-6 text-brand-orange" />,
      title: "Email",
      details: ["info@lymattica.gr", "emergency@lymattica.gr"],
      action: "mailto:info@lymattica.gr"
    },
    {
      icon: <MapPin className="w-6 h-6 text-brand-orange" />,
      title: "Διεύθυνση",
      details: ["Αθήνα, Αττική", "Εξυπηρετούμε όλη την περιοχή"],
      action: null
    },
    {
      icon: <Clock className="w-6 h-6 text-brand-orange" />,
      title: "Ώρες Λειτουργίας",
      details: ["24/7 Έκτακτες ανάγκες", "Δευτ-Παρ: 8:00-18:00"],
      action: null
    }
  ];

  return (
    <section id="contact" className="py-20 bg-bg-page">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="heading-1 text-text-primary mb-4">
            Επικοινωνήστε μαζί μας
          </h2>
          <p className="body-lg text-text-secondary max-w-2xl mx-auto">
            Είμαστε εδώ για να σας βοηθήσουμε με οποιοδήποτε πρόβλημα αποχέτευσης, 
            άντλησης ή διαχείρισης αποβλήτων.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div>
            <h3 className="heading-3 text-text-primary mb-8">Στοιχεία Επικοινωνίας</h3>
            
            <div className="space-y-6 mb-8">
              {contactInfo.map((info, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-12 h-12 bg-bg-subtle rounded-lg flex items-center justify-center flex-shrink-0">
                    {info.icon}
                  </div>
                  <div>
                    <h4 className="heading-4 text-text-primary mb-2">{info.title}</h4>
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="body-md text-text-secondary">
                        {info.action && idx === 0 ? (
                          <a href={info.action} className="hover:text-brand-green transition-colors">
                            {detail}
                          </a>
                        ) : (
                          detail
                        )}
                      </p>
                    ))}
                  </div>
                </div>
              ))}
            </div>

            {/* Emergency Notice */}
            <div className="bg-brand-orange/10 border-l-4 border-brand-orange rounded-lg p-6">
              <h4 className="heading-4 text-text-primary mb-2">Έκτακτες Ανάγκες</h4>
              <p className="body-md text-text-secondary mb-3">
                Για επείγουσες περιπτώσεις αποχέτευσης ή άντλησης νερού, 
                καλέστε μας άμεσα στο 24ωρο τηλέφωνό μας.
              </p>
              <a 
                href="tel:+306945678901" 
                className="btn-primary inline-flex items-center"
              >
                <Phone className="w-4 h-4 mr-2" />
                Κλήση Έκτακτης Ανάγκης
              </a>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-white rounded-2xl p-8">
            <h3 className="heading-3 text-text-primary mb-6">Στείλτε μας μήνυμα</h3>
            
            {/* Success Message */}
            {submitStatus === 'success' && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-start">
                <CheckCircle className="w-5 h-5 text-green-600 mr-3 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-green-800 font-medium mb-1">Επιτυχής Αποστολή!</h4>
                  <p className="text-green-700 text-sm">
                    Το μήνυμά σας στάλθηκε επιτυχώς. Θα επικοινωνήσουμε μαζί σας σύντομα.
                  </p>
                </div>
              </div>
            )}

            {/* Error Message */}
            {submitStatus === 'error' && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-start">
                <AlertCircle className="w-5 h-5 text-red-600 mr-3 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="text-red-800 font-medium mb-1">Σφάλμα Αποστολής</h4>
                  <p className="text-red-700 text-sm">
                    Προέκυψε σφάλμα κατά την αποστολή. Παρακαλώ δοκιμάστε ξανά ή καλέστε μας.
                  </p>
                </div>
              </div>
            )}
            
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block body-md text-text-primary mb-2">
                    Όνομα *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 border border-border-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                    placeholder="Το όνομά σας"
                  />
                </div>
                <div>
                  <label className="block body-md text-text-primary mb-2">
                    Τηλέφωνο *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    required
                    disabled={isSubmitting}
                    className="w-full px-4 py-3 border border-border-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                    placeholder="Το τηλέφωνό σας"
                  />
                </div>
              </div>

              <div>
                <label className="block body-md text-text-primary mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-border-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                  placeholder="Το email σας"
                />
              </div>

              <div>
                <label className="block body-md text-text-primary mb-2">
                  Υπηρεσία
                </label>
                <select
                  name="service"
                  value={formData.service}
                  onChange={handleChange}
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-border-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent disabled:bg-gray-100 disabled:cursor-not-allowed"
                >
                  <option value="">Επιλέξτε υπηρεσία</option>
                  <option value="sewage">Αποχέτευση & Καθαρισμός</option>
                  <option value="pumping">Άντληση Νερού</option>
                  <option value="waste">Μεταφορά Αποβλήτων</option>
                  <option value="emergency">Έκτακτη Ανάγκη</option>
                </select>
              </div>

              <div>
                <label className="block body-md text-text-primary mb-2">
                  Μήνυμα *
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows={4}
                  disabled={isSubmitting}
                  className="w-full px-4 py-3 border border-border-medium rounded-lg focus:outline-none focus:ring-2 focus:ring-brand-green focus:border-transparent resize-none disabled:bg-gray-100 disabled:cursor-not-allowed"
                  placeholder="Περιγράψτε το πρόβλημα ή την ανάγκη σας..."
                ></textarea>
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-primary w-full disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isSubmitting ? (
                  <>
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin mr-2"></div>
                    Αποστολή...
                  </>
                ) : (
                  <>
                    <Send className="w-5 h-5 mr-2" />
                    Αποστολή Μηνύματος
                  </>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;