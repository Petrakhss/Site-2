import React, { useState, useEffect } from "react";
import { Droplets, Wrench, Truck, Clock, Shield, Users } from "lucide-react";
import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Services = () => {
  const [services, setServices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const response = await axios.get(`${API}/services`);
      setServices(response.data);
      setLoading(false);
    } catch (err) {
      console.error('Error fetching services:', err);
      setError('Σφάλμα φόρτωσης υπηρεσιών');
      setLoading(false);
      
      // Fallback to default services if API fails
      setServices([
        {
          id: "sewage-service",
          service_type: "sewage",
          title_gr: "Αποχέτευση & Καθαρισμός",
          description_gr: "Καθαρισμός και συντήρηση αποχετευτικών συστημάτων, απόφραξη σωλήνων και δικτύων αποχέτευσης με σύγχρονο εξοπλισμό.",
          features: ["Απόφραξη σωλήνων", "Καθαρισμός φρεατίων", "Συντήρηση δικτύων"],
          availability: "24/7",
          response_time: "30 minutes"
        },
        {
          id: "pumping-service",
          service_type: "pumping",
          title_gr: "Άντληση Νερού",
          description_gr: "Υπηρεσίες άντλησης νερού από υπόγεια, κελάρια, και πλημμυρισμένους χώρους με εξειδικευμένο εξοπλισμό υψηλής απόδοσης.",
          features: ["Άντληση από κελάρια", "Καθαρισμός πλημμυρών", "Έκτακτες παρεμβάσεις"],
          availability: "24/7",
          response_time: "15 minutes"
        },
        {
          id: "waste-service",
          service_type: "waste",
          title_gr: "Μεταφορά Αποβλήτων",
          description_gr: "Ασφαλής και περιβαλλοντικά υπεύθυνη μεταφορά και διάθεση αποβλήτων σύμφωνα με τους κανονισμούς της Ελληνικής νομοθεσίας.",
          features: ["Υγρά απόβλητα", "Βιομηχανικά απόβλητα", "Νόμιμη διάθεση"],
          availability: "Business hours",
          response_time: "Same day"
        }
      ]);
    }
  };

  const getServiceIcon = (serviceType) => {
    const iconProps = "w-8 h-8 text-white";
    switch (serviceType) {
      case 'sewage':
        return <Droplets className={iconProps} />;
      case 'pumping':
        return <Wrench className={iconProps} />;
      case 'waste':
        return <Truck className={iconProps} />;
      default:
        return <Droplets className={iconProps} />;
    }
  };

  const features = [
    {
      icon: <Clock className="w-6 h-6 text-brand-orange" />,
      title: "24/7 Διαθεσιμότητα",
      description: "Είμαστε διαθέσιμοι όλο το 24ωρο για έκτακτες ανάγκες"
    },
    {
      icon: <Shield className="w-6 h-6 text-brand-orange" />,
      title: "Πλήρης Ασφάλιση",
      description: "Όλες οι εργασίες είναι ασφαλισμένες και πιστοποιημένες"
    },
    {
      icon: <Users className="w-6 h-6 text-brand-orange" />,
      title: "Έμπειρη Ομάδα",
      description: "Πάνω από 15 χρόνια εμπειρίας στον τομέα"
    }
  ];

  if (loading) {
    return (
      <section id="services" className="py-20 bg-bg-page">
        <div className="container">
          <div className="text-center">
            <div className="w-12 h-12 border-4 border-brand-green border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="body-lg text-text-secondary">Φόρτωση υπηρεσιών...</p>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="services" className="py-20 bg-bg-page">
      <div className="container">
        <div className="text-center mb-16">
          <h2 className="heading-1 text-text-primary mb-4">
            Οι Υπηρεσίες μας
          </h2>
          <p className="body-lg text-text-secondary max-w-2xl mx-auto">
            Παρέχουμε ολοκληρωμένες λύσεις για την διαχείριση αποβλήτων και 
            υδρολογικών προβλημάτων στην Αθήνα και την ευρύτερη περιοχή.
          </p>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-yellow-50 border border-yellow-200 rounded-lg text-center">
            <p className="text-yellow-800">{error} - Χρησιμοποιούνται προεπιλεγμένες υπηρεσίες</p>
          </div>
        )}

        {/* Main Services */}
        <div className="design-grid mb-20">
          {services.map((service, index) => (
            <div key={service.id || index} className="design-card hover-lift">
              <div className="card-icon bg-brand-green mb-6">
                {getServiceIcon(service.service_type)}
              </div>
              <h3 className="card-title">{service.title_gr}</h3>
              <p className="card-description mb-6">{service.description_gr}</p>
              <ul className="space-y-2 mb-4">
                {service.features && service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-center text-text-secondary">
                    <div className="w-2 h-2 bg-brand-green rounded-full mr-3 flex-shrink-0"></div>
                    <span className="body-sm">{feature}</span>
                  </li>
                ))}
              </ul>
              {service.availability && (
                <div className="text-center mt-4 p-3 bg-bg-subtle rounded-lg">
                  <span className="body-sm text-text-primary font-medium">
                    Διαθεσιμότητα: {service.availability}
                  </span>
                  {service.response_time && (
                    <div className="body-sm text-text-secondary">
                      Χρόνος ανταπόκρισης: {service.response_time}
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Additional Features */}
        <div className="bg-white rounded-2xl p-8 md:p-12">
          <div className="text-center mb-12">
            <h3 className="heading-2 text-text-primary mb-4">
              Γιατί να επιλέξετε τη Lymattica;
            </h3>
            <p className="body-lg text-text-secondary">
              Η αξιοπιστία και η ποιότητα είναι οι βασικές μας αξίες
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <div key={index} className="text-center">
                <div className="w-16 h-16 bg-bg-subtle rounded-2xl flex items-center justify-center mx-auto mb-4">
                  {feature.icon}
                </div>
                <h4 className="heading-4 text-text-primary mb-2">{feature.title}</h4>
                <p className="body-md text-text-secondary">{feature.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Services;