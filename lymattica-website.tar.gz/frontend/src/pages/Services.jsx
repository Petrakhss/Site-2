import React from "react";
import { ArrowLeft, Shield, Clock, Award, Users, CheckCircle, Phone, Mail } from "lucide-react";
import { Link } from "react-router-dom";
import Header from "../components/Header";
import Footer from "../components/Footer";

const ServicesPage = () => {
  const qualityStandards = [
    {
      icon: <Shield className="w-8 h-8 text-white" />,
      title: "Πιστοποιημένοι Τεχνικοί",
      description: "Όλοι οι τεχνικοί μας διαθέτουν τις απαραίτητες πιστοποιήσεις και εκπαίδευση για την ασφαλή εκτέλεση των εργασιών."
    },
    {
      icon: <Award className="w-8 h-8 text-white" />,
      title: "Σύγχρονος Εξοπλισμός",
      description: "Χρησιμοποιούμε την πιο σύγχρονη τεχνολογία και εξοπλισμό για να εξασφαλίσουμε άριστα αποτελέσματα."
    },
    {
      icon: <Clock className="w-8 h-8 text-white" />,
      title: "24/7 Διαθεσιμότητα",
      description: "Είμαστε διαθέσιμοι όλο το 24ωρο για έκτακτες ανάγκες και επείγουσες παρεμβάσεις."
    },
    {
      icon: <Users className="w-8 h-8 text-white" />,
      title: "Έμπειρη Ομάδα",
      description: "Με πάνω από 15 χρόνια εμπειρίας, η ομάδα μας χειρίζεται κάθε περίπτωση με επαγγελματισμό."
    }
  ];

  const detailedServices = [
    {
      title: "Αποχέτευση & Καθαρισμός",
      description: "Ολοκληρωμένες υπηρεσίες αποχέτευσης για κατοικίες και επιχειρήσεις",
      procedures: [
        "Διάγνωση προβλήματος με ειδικό εξοπλισμό",
        "Καθαρισμός σωλήνων με υψηλή πίεση νερού",
        "Απόφραξη με σπιράλ και ειδικά εργαλεία",
        "Καθαρισμός φρεατίων και δικτύων",
        "Έλεγχος και συντήρηση συστημάτων"
      ],
      equipment: [
        "Μηχάνηματα υψηλής πίεσης",
        "Ηλεκτρικές και υδραυλικές σπιράλ",
        "Κάμερες επιθεώρησης σωλήνων",
        "Αναρρόφηση λυμάτων"
      ],
      businessServices: "Συμβόλαια συντήρησης για πολυκατοικίες, ξενοδοχεία και εστιατόρια"
    },
    {
      title: "Άντληση Νερού",
      description: "Γρήγορη και αποτελεσματική άντληση νερού από κάθε χώρο",
      procedures: [
        "Άμεση αξιολόγηση της κατάστασης",
        "Τοποθέτηση κατάλληλων αντλιών",
        "Αποστράγγιση νερού με ασφάλεια",
        "Καθαρισμός και απολύμανση χώρου",
        "Έλεγχος για πρόληψη μελλοντικών προβλημάτων"
      ],
      equipment: [
        "Υποβρύχιες αντλίες υψηλής απόδοσης",
        "Φορητές αντλίες έκτακτης ανάγκης",
        "Συστήματα αποστράγγισης",
        "Εξοπλισμός στεγνοποίησης"
      ],
      businessServices: "24ωρη κάλυψη για επιχειρήσεις και βιομηχανικούς χώρους"
    },
    {
      title: "Μεταφορά Αποβλήτων",
      description: "Ασφαλής μεταφορά και διάθεση αποβλήτων σύμφωνα με τους κανονισμούς",
      procedures: [
        "Κατηγοριοποίηση αποβλήτων",
        "Ασφαλής συλλογή και συσκευασία",
        "Μεταφορά με ειδικά οχήματα",
        "Διάθεση σε εγκεκριμένες εγκαταστάσεις",
        "Παροχή πιστοποιητικών διάθεσης"
      ],
      equipment: [
        "Ειδικά οχήματα μεταφοράς",
        "Δοχεία και συστήματα ασφαλείας",
        "Εξοπλισμός φόρτωσης/εκφόρτωσης",
        "Συστήματα παρακολούθησης"
      ],
      businessServices: "Συμβόλαια τακτικής συλλογής για επιχειρήσεις, εργοστάσια και μεγάλες εγκαταστάσεις. Εξειδικευμένη διαχείριση βιομηχανικών και επικίνδυνων αποβλήτων."
    }
  ];

  const businessBenefits = [
    "Εξοικονόμηση κόστους με πακέτα υπηρεσιών",
    "Προγραμματισμένη συντήρηση και έλεγχοι",
    "Προτεραιότητα σε έκτακτες ανάγκες",
    "Εξειδικευμένη εξυπηρέτηση B2B",
    "Νομική συμμόρφωση και πιστοποιήσεις",
    "Αναφορές και τεκμηρίωση εργασιών"
  ];

  return (
    <div className="min-h-screen">
      <Header />
      
      {/* Back Navigation */}
      <div className="bg-bg-page py-4 border-b border-border-light">
        <div className="container">
          <Link to="/" className="inline-flex items-center text-text-secondary hover:text-brand-green transition-colors">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Επιστροφή στην Αρχική
          </Link>
        </div>
      </div>

      {/* Page Header */}
      <section className="py-16 bg-bg-page">
        <div className="container">
          <div className="text-center max-w-4xl mx-auto">
            <h1 className="heading-1 text-text-primary mb-6">
              Οι Υπηρεσίες μας
            </h1>
            <p className="body-xl text-text-secondary mb-8">
              Παρέχουμε ολοκληρωμένες και αξιόπιστες λύσεις για την διαχείριση αποβλήτων, 
              αποχέτευσης και υδρολογικών προβλημάτων με την υψηλότερη ποιότητα υπηρεσιών.
            </p>
          </div>
        </div>
      </section>

      {/* Quality Standards */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="heading-2 text-text-primary mb-4">
              Πρότυπα Ποιότητας
            </h2>
            <p className="body-lg text-text-secondary max-w-2xl mx-auto">
              Η δέσμευσή μας για υψηλή ποιότητα διασφαλίζεται μέσω αυστηρών προτύπων και διαδικασιών
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {qualityStandards.map((standard, index) => (
              <div key={index} className="text-center">
                <div className="w-20 h-20 bg-brand-green rounded-2xl flex items-center justify-center mx-auto mb-6">
                  {standard.icon}
                </div>
                <h3 className="heading-4 text-text-primary mb-4">{standard.title}</h3>
                <p className="body-md text-text-secondary">{standard.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Detailed Services */}
      <section className="py-20 bg-bg-page">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="heading-2 text-text-primary mb-4">
              Αναλυτικές Υπηρεσίες
            </h2>
            <p className="body-lg text-text-secondary max-w-2xl mx-auto">
              Κάθε υπηρεσία εκτελείται με συγκεκριμένες διαδικασίες και εξειδικευμένο εξοπλισμό
            </p>
          </div>

          <div className="space-y-16">
            {detailedServices.map((service, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 md:p-12">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
                  <div>
                    <h3 className="heading-2 text-text-primary mb-4">{service.title}</h3>
                    <p className="body-lg text-text-secondary mb-8">{service.description}</p>
                    
                    <div className="mb-8">
                      <h4 className="heading-4 text-text-primary mb-4">Διαδικασίες Εργασίας</h4>
                      <ul className="space-y-3">
                        {service.procedures.map((procedure, idx) => (
                          <li key={idx} className="flex items-start">
                            <CheckCircle className="w-5 h-5 text-brand-green mr-3 mt-0.5 flex-shrink-0" />
                            <span className="body-md text-text-secondary">{procedure}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    {service.businessServices && (
                      <div className="bg-bg-subtle rounded-lg p-6">
                        <h4 className="heading-4 text-text-primary mb-3">Επιχειρηματικές Υπηρεσίες</h4>
                        <p className="body-md text-text-secondary">{service.businessServices}</p>
                      </div>
                    )}
                  </div>

                  <div>
                    <h4 className="heading-4 text-text-primary mb-6">Εξοπλισμός & Τεχνολογία</h4>
                    <div className="grid grid-cols-1 gap-4">
                      {service.equipment.map((item, idx) => (
                        <div key={idx} className="flex items-center p-4 bg-bg-subtle rounded-lg">
                          <div className="w-3 h-3 bg-brand-orange rounded-full mr-4 flex-shrink-0"></div>
                          <span className="body-md text-text-secondary">{item}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Business Services Section */}
      <section className="py-20 bg-white">
        <div className="container">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="heading-2 text-text-primary mb-6">
                Επιχειρηματικά Συμβόλαια
              </h2>
              <p className="body-lg text-text-secondary mb-8">
                Προσφέρουμε εξειδικευμένες λύσεις για επιχειρήσεις, βιομηχανίες και μεγάλες εγκαταστάσεις 
                με συμβόλαια συντήρησης και τακτικής εξυπηρέτησης.
              </p>
              
              <div className="space-y-4 mb-8">
                {businessBenefits.map((benefit, index) => (
                  <div key={index} className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-brand-green mr-3 flex-shrink-0" />
                    <span className="body-md text-text-secondary">{benefit}</span>
                  </div>
                ))}
              </div>

              <div className="flex flex-col sm:flex-row gap-4">
                <a href="tel:+302101234567" className="btn-primary">
                  <Phone className="w-5 h-5 mr-2" />
                  Κλήση για Προσφορά
                </a>
                <a href="mailto:info@lymattica.gr" className="btn-secondary">
                  <Mail className="w-5 h-5 mr-2" />
                  Email Επικοινωνία
                </a>
              </div>
            </div>

            <div className="bg-bg-page rounded-2xl p-8">
              <h3 className="heading-3 text-text-primary mb-6">Τύποι Συμβολαίων</h3>
              
              <div className="space-y-6">
                <div className="border-l-4 border-brand-green pl-6">
                  <h4 className="heading-4 text-text-primary mb-2">Μηνιαία Συντήρηση</h4>
                  <p className="body-sm text-text-secondary">
                    Τακτικοί έλεγχοι και καθαρισμοί για πρόληψη προβλημάτων
                  </p>
                </div>
                
                <div className="border-l-4 border-brand-orange pl-6">
                  <h4 className="heading-4 text-text-primary mb-2">Συλλογή Αποβλήτων</h4>
                  <p className="body-sm text-text-secondary">
                    Προγραμματισμένη συλλογή και διάθεση αποβλήτων
                  </p>
                </div>
                
                <div className="border-l-4 border-brand-green pl-6">
                  <h4 className="heading-4 text-text-primary mb-2">Έκτακτη Κάλυψη</h4>
                  <p className="body-sm text-text-secondary">
                    Προτεραιότητα σε επείγουσες παρεμβάσεις 24/7
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quality Guarantee */}
      <section className="py-20 bg-brand-green text-white">
        <div className="container">
          <div className="text-center max-w-4xl mx-auto">
            <h2 className="heading-2 mb-6">Εγγύηση Ποιότητας</h2>
            <p className="body-xl mb-8">
              Όλες οι εργασίες μας καλύπτονται από πλήρη ασφάλιση και εγγύηση ποιότητας. 
              Η ικανοποίησή σας είναι η δική μας επιτυχία.
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
              <div>
                <div className="text-4xl font-bold mb-2">100%</div>
                <div className="body-md">Ικανοποίηση Πελατών</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">24/7</div>
                <div className="body-md">Διαθεσιμότητα</div>
              </div>
              <div>
                <div className="text-4xl font-bold mb-2">15+</div>
                <div className="body-md">Χρόνια Εμπειρίας</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default ServicesPage;