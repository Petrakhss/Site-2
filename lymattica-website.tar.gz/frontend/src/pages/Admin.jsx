import React, { useState, useEffect } from "react";
import { Lock, Users, MessageSquare, TrendingUp, Eye, CheckCircle, Clock, AlertTriangle } from "lucide-react";
import axios from "axios";

const BACKEND_URL = process.env.REACT_APP_BACKEND_URL;
const API = `${BACKEND_URL}/api`;

const Admin = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loginData, setLoginData] = useState({ username: "", password: "" });
  const [loginError, setLoginError] = useState("");
  const [contacts, setContacts] = useState([]);
  const [stats, setStats] = useState(null);
  const [selectedContact, setSelectedContact] = useState(null);

  useEffect(() => {
    checkAuthStatus();
  }, []);

  const checkAuthStatus = () => {
    const token = localStorage.getItem('admin_token');
    if (token) {
      setIsAuthenticated(true);
      fetchDashboardData();
    }
    setLoading(false);
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoginError("");
    
    try {
      const response = await axios.post(`${API}/auth/login`, loginData);
      const { access_token } = response.data;
      
      localStorage.setItem('admin_token', access_token);
      axios.defaults.headers.common['Authorization'] = `Bearer ${access_token}`;
      
      setIsAuthenticated(true);
      fetchDashboardData();
    } catch (error) {
      setLoginError("Λάθος όνομα χρήστη ή κωδικός");
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('admin_token');
    delete axios.defaults.headers.common['Authorization'];
    setIsAuthenticated(false);
    setContacts([]);
    setStats(null);
  };

  const fetchDashboardData = async () => {
    try {
      const token = localStorage.getItem('admin_token');
      if (!token) return;

      axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;

      const [contactsRes, statsRes] = await Promise.all([
        axios.get(`${API}/contacts?limit=20`),
        axios.get(`${API}/stats/contacts`)
      ]);

      setContacts(contactsRes.data);
      setStats(statsRes.data);
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      if (error.response?.status === 401) {
        handleLogout();
      }
    }
  };

  const updateContactStatus = async (contactId, status) => {
    try {
      await axios.put(`${API}/contacts/${contactId}`, { status });
      setContacts(contacts.map(contact => 
        contact.id === contactId ? { ...contact, status } : contact
      ));
      if (stats) {
        fetchDashboardData(); // Refresh stats
      }
    } catch (error) {
      console.error('Error updating contact status:', error);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'new': return 'bg-blue-100 text-blue-800';
      case 'contacted': return 'bg-yellow-100 text-yellow-800';
      case 'resolved': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'new': return <AlertTriangle className="w-4 h-4" />;
      case 'contacted': return <Clock className="w-4 h-4" />;
      case 'resolved': return <CheckCircle className="w-4 h-4" />;
      default: return <MessageSquare className="w-4 h-4" />;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-brand-green border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="max-w-md w-full space-y-8">
          <div className="text-center">
            <Lock className="mx-auto h-12 w-12 text-brand-green" />
            <h2 className="mt-6 text-3xl font-extrabold text-gray-900">
              Lymattica Admin
            </h2>
            <p className="mt-2 text-sm text-gray-600">
              Σύνδεση στο σύστημα διαχείρισης
            </p>
          </div>
          
          <form className="mt-8 space-y-6" onSubmit={handleLogin}>
            <div className="rounded-md shadow-sm -space-y-px">
              <div>
                <input
                  type="text"
                  required
                  value={loginData.username}
                  onChange={(e) => setLoginData({...loginData, username: e.target.value})}
                  className="relative block w-full appearance-none rounded-none rounded-t-md border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-brand-green focus:border-brand-green focus:z-10 sm:text-sm"
                  placeholder="Όνομα χρήστη"
                />
              </div>
              <div>
                <input
                  type="password"
                  required
                  value={loginData.password}
                  onChange={(e) => setLoginData({...loginData, password: e.target.value})}
                  className="relative block w-full appearance-none rounded-none rounded-b-md border border-gray-300 px-3 py-2 text-gray-900 placeholder-gray-500 focus:outline-none focus:ring-brand-green focus:border-brand-green focus:z-10 sm:text-sm"
                  placeholder="Κωδικός"
                />
              </div>
            </div>

            {loginError && (
              <div className="text-red-600 text-sm text-center">{loginError}</div>
            )}

            <div>
              <button
                type="submit"
                className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-brand-green hover:bg-green-hover focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-green"
              >
                Σύνδεση
              </button>
            </div>

            <div className="text-xs text-gray-500 text-center">
              Default: username: admin, password: lymattica2024
            </div>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-6">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">Lymattica Admin</h1>
            </div>
            <button
              onClick={handleLogout}
              className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 rounded-md text-sm font-medium"
            >
              Αποσύνδεση
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Users className="h-6 w-6 text-gray-400" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Συνολικά Μηνύματα
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.total_contacts}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <AlertTriangle className="h-6 w-6 text-blue-400" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Νέα
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.new_contacts}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <Clock className="h-6 w-6 text-yellow-400" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Σε Επικοινωνία
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.contacted_contacts}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-white overflow-hidden shadow rounded-lg">
              <div className="p-5">
                <div className="flex items-center">
                  <div className="flex-shrink-0">
                    <CheckCircle className="h-6 w-6 text-green-400" />
                  </div>
                  <div className="ml-5 w-0 flex-1">
                    <dl>
                      <dt className="text-sm font-medium text-gray-500 truncate">
                        Επιλυμένα
                      </dt>
                      <dd className="text-lg font-medium text-gray-900">
                        {stats.resolved_contacts}
                      </dd>
                    </dl>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Contacts Table */}
        <div className="bg-white shadow overflow-hidden sm:rounded-md">
          <div className="px-4 py-5 sm:px-6">
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Πρόσφατα Μηνύματα Επικοινωνίας
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              Διαχείριση και παρακολούθηση μηνυμάτων πελατών
            </p>
          </div>
          
          <ul className="divide-y divide-gray-200">
            {contacts.map((contact) => (
              <li key={contact.id}>
                <div className="px-4 py-4 flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 h-10 w-10">
                      <div className="h-10 w-10 rounded-full bg-brand-green flex items-center justify-center">
                        <span className="text-sm font-medium text-white">
                          {contact.name.charAt(0).toUpperCase()}
                        </span>
                      </div>
                    </div>
                    <div className="ml-4">
                      <div className="flex items-center">
                        <div className="text-sm font-medium text-gray-900">
                          {contact.name}
                        </div>
                        <span className={`ml-2 inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(contact.status)}`}>
                          {getStatusIcon(contact.status)}
                          <span className="ml-1 capitalize">
                            {contact.status === 'new' ? 'Νέο' : 
                             contact.status === 'contacted' ? 'Επικοινωνία' : 'Επιλύθηκε'}
                          </span>
                        </span>
                      </div>
                      <div className="text-sm text-gray-500">
                        {contact.email} • {contact.phone}
                      </div>
                      <div className="text-sm text-gray-500">
                        {new Date(contact.timestamp).toLocaleString('el-GR')}
                      </div>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={() => setSelectedContact(contact)}
                      className="text-brand-green hover:text-green-hover"
                    >
                      <Eye className="h-5 w-5" />
                    </button>
                    
                    {contact.status === 'new' && (
                      <button
                        onClick={() => updateContactStatus(contact.id, 'contacted')}
                        className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded text-xs"
                      >
                        Επικοινωνία
                      </button>
                    )}
                    
                    {contact.status === 'contacted' && (
                      <button
                        onClick={() => updateContactStatus(contact.id, 'resolved')}
                        className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs"
                      >
                        Επίλυση
                      </button>
                    )}
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Contact Detail Modal */}
      {selectedContact && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-96 overflow-y-auto">
            <div className="px-6 py-4 border-b border-gray-200">
              <h3 className="text-lg font-medium text-gray-900">
                Λεπτομέρειες Μηνύματος
              </h3>
            </div>
            
            <div className="px-6 py-4 space-y-4">
              <div>
                <dt className="text-sm font-medium text-gray-500">Όνομα</dt>
                <dd className="text-sm text-gray-900">{selectedContact.name}</dd>
              </div>
              
              <div>
                <dt className="text-sm font-medium text-gray-500">Email</dt>
                <dd className="text-sm text-gray-900">
                  <a href={`mailto:${selectedContact.email}`} className="text-brand-green hover:underline">
                    {selectedContact.email}
                  </a>
                </dd>
              </div>
              
              <div>
                <dt className="text-sm font-medium text-gray-500">Τηλέφωνο</dt>
                <dd className="text-sm text-gray-900">
                  <a href={`tel:${selectedContact.phone}`} className="text-brand-green hover:underline">
                    {selectedContact.phone}
                  </a>
                </dd>
              </div>
              
              {selectedContact.service && (
                <div>
                  <dt className="text-sm font-medium text-gray-500">Υπηρεσία</dt>
                  <dd className="text-sm text-gray-900 capitalize">{selectedContact.service}</dd>
                </div>
              )}
              
              <div>
                <dt className="text-sm font-medium text-gray-500">Μήνυμα</dt>
                <dd className="text-sm text-gray-900 whitespace-pre-wrap">{selectedContact.message}</dd>
              </div>
              
              <div>
                <dt className="text-sm font-medium text-gray-500">Ημερομηνία</dt>
                <dd className="text-sm text-gray-900">
                  {new Date(selectedContact.timestamp).toLocaleString('el-GR')}
                </dd>
              </div>
            </div>
            
            <div className="px-6 py-4 border-t border-gray-200 flex justify-end space-x-3">
              <button
                onClick={() => setSelectedContact(null)}
                className="px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 hover:bg-gray-50"
              >
                Κλείσιμο
              </button>
              
              <a
                href={`tel:${selectedContact.phone}`}
                className="bg-brand-green text-white px-4 py-2 rounded-md text-sm font-medium hover:bg-green-hover"
              >
                Κλήση
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Admin;