from pydantic import BaseModel, Field, EmailStr, validator
from typing import Optional, List
from datetime import datetime
from enum import Enum
import uuid

# Enums for better type safety
class ContactStatus(str, Enum):
    NEW = "new"
    CONTACTED = "contacted"
    RESOLVED = "resolved"

class ServiceType(str, Enum):
    SEWAGE = "sewage"
    PUMPING = "pumping"
    WASTE = "waste"
    EMERGENCY = "emergency"

class UserRole(str, Enum):
    ADMIN = "admin"
    OPERATOR = "operator"

# Contact Submission Models
class ContactSubmissionCreate(BaseModel):
    name: str = Field(..., min_length=2, max_length=100)
    email: EmailStr
    phone: str = Field(..., min_length=10, max_length=20)
    service: Optional[ServiceType] = None
    message: str = Field(..., min_length=10, max_length=2000)

    @validator('phone')
    def validate_phone(cls, v):
        # Remove spaces and validate Greek phone format
        clean_phone = v.replace(' ', '').replace('-', '')
        if not clean_phone.startswith(('210', '211', '213', '214', '215', '216', '217', '218', '219', '22', '23', '24', '25', '26', '27', '28', '29', '69')):
            raise ValueError('Please enter a valid Greek phone number')
        return clean_phone

class ContactSubmission(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    phone: str
    service: Optional[ServiceType] = None
    message: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)
    status: ContactStatus = ContactStatus.NEW
    admin_notes: Optional[str] = None
    ip_address: Optional[str] = None
    user_agent: Optional[str] = None

class ContactSubmissionUpdate(BaseModel):
    status: Optional[ContactStatus] = None
    admin_notes: Optional[str] = None

# Service Models
class ServiceCreate(BaseModel):
    service_type: ServiceType
    title_gr: str = Field(..., min_length=5, max_length=200)
    description_gr: str = Field(..., min_length=20, max_length=1000)
    features: List[str] = Field(default_factory=list)
    pricing_info: Optional[str] = None
    availability: str = Field(default="24/7")
    response_time: str = Field(default="30 minutes")
    active: bool = True
    order: int = Field(default=0)

class Service(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    service_type: ServiceType
    title_gr: str
    description_gr: str
    features: List[str]
    pricing_info: Optional[str] = None
    availability: str
    response_time: str
    active: bool
    order: int
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(default_factory=datetime.utcnow)

class ServiceUpdate(BaseModel):
    title_gr: Optional[str] = None
    description_gr: Optional[str] = None
    features: Optional[List[str]] = None
    pricing_info: Optional[str] = None
    availability: Optional[str] = None
    response_time: Optional[str] = None
    active: Optional[bool] = None
    order: Optional[int] = None

# Admin User Models
class AdminUserCreate(BaseModel):
    username: str = Field(..., min_length=3, max_length=50)
    email: EmailStr
    password: str = Field(..., min_length=8)
    role: UserRole = UserRole.OPERATOR

class AdminUser(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    username: str
    email: EmailStr
    password_hash: str
    role: UserRole
    created_at: datetime = Field(default_factory=datetime.utcnow)
    last_login: Optional[datetime] = None
    active: bool = True

class AdminUserLogin(BaseModel):
    username: str
    password: str

class AdminUserResponse(BaseModel):
    id: str
    username: str
    email: EmailStr
    role: UserRole
    created_at: datetime
    last_login: Optional[datetime] = None

# Statistics Models
class ContactStats(BaseModel):
    total_contacts: int
    new_contacts: int
    contacted_contacts: int
    resolved_contacts: int
    today_contacts: int
    this_week_contacts: int
    this_month_contacts: int

class ServiceStats(BaseModel):
    total_services: int
    active_services: int
    service_breakdown: dict  # service_type -> count

class DashboardStats(BaseModel):
    contact_stats: ContactStats
    service_stats: ServiceStats
    recent_contacts: List[ContactSubmission]

# Email Configuration Models
class EmailConfig(BaseModel):
    smtp_server: str
    smtp_port: int
    smtp_username: str
    smtp_password: str
    from_email: str
    from_name: str = "Lymattica"
    
class EmailNotification(BaseModel):
    to_email: str
    subject: str
    message: str
    contact_id: Optional[str] = None
    
# Response Models
class SuccessResponse(BaseModel):
    success: bool = True
    message: str
    data: Optional[dict] = None

class ErrorResponse(BaseModel):
    success: bool = False
    error: str
    details: Optional[str] = None

# JWT Token Models
class Token(BaseModel):
    access_token: str
    token_type: str = "bearer"
    expires_in: int

class TokenData(BaseModel):
    username: Optional[str] = None
    user_id: Optional[str] = None
    role: Optional[UserRole] = None