from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from typing import Optional
import os
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class Database:
    client: Optional[AsyncIOMotorClient] = None
    database: Optional[AsyncIOMotorDatabase] = None

# Database instance
db = Database()

async def connect_to_mongo():
    """Create database connection"""
    try:
        db.client = AsyncIOMotorClient(os.environ["MONGO_URL"])
        db.database = db.client[os.environ["DB_NAME"]]
        
        # Test the connection
        await db.client.admin.command('ping')
        logger.info("Connected to MongoDB successfully")
        
        # Create indexes for better performance
        await create_indexes()
        
    except Exception as e:
        logger.error(f"Could not connect to MongoDB: {e}")
        raise

async def close_mongo_connection():
    """Close database connection"""
    if db.client:
        db.client.close()
        logger.info("Disconnected from MongoDB")

async def create_indexes():
    """Create database indexes for better performance"""
    try:
        # Contact submissions indexes
        await db.database.contact_submissions.create_index("timestamp")
        await db.database.contact_submissions.create_index("status")
        await db.database.contact_submissions.create_index("email")
        
        # Services indexes
        await db.database.services.create_index("service_type")
        await db.database.services.create_index("active")
        await db.database.services.create_index("order")
        
        # Admin users indexes
        await db.database.admin_users.create_index("username", unique=True)
        await db.database.admin_users.create_index("email", unique=True)
        
        logger.info("Database indexes created successfully")
        
    except Exception as e:
        logger.warning(f"Could not create indexes: {e}")

# Contact Submissions Repository
class ContactRepository:
    
    @staticmethod
    async def create_contact(contact_data: dict) -> dict:
        """Create a new contact submission"""
        result = await db.database.contact_submissions.insert_one(contact_data)
        contact_data["_id"] = str(result.inserted_id)
        return contact_data
    
    @staticmethod
    async def get_contacts(skip: int = 0, limit: int = 50, status: Optional[str] = None) -> list:
        """Get contact submissions with pagination"""
        query = {}
        if status:
            query["status"] = status
            
        cursor = db.database.contact_submissions.find(query).sort("timestamp", -1).skip(skip).limit(limit)
        contacts = []
        async for contact in cursor:
            contact["_id"] = str(contact["_id"])
            contacts.append(contact)
        return contacts
    
    @staticmethod
    async def get_contact_by_id(contact_id: str) -> Optional[dict]:
        """Get contact by ID"""
        contact = await db.database.contact_submissions.find_one({"id": contact_id})
        if contact:
            contact["_id"] = str(contact["_id"])
        return contact
    
    @staticmethod
    async def update_contact(contact_id: str, update_data: dict) -> bool:
        """Update contact submission"""
        update_data["updated_at"] = datetime.utcnow()
        result = await db.database.contact_submissions.update_one(
            {"id": contact_id}, 
            {"$set": update_data}
        )
        return result.modified_count > 0
    
    @staticmethod
    async def delete_contact(contact_id: str) -> bool:
        """Delete contact submission"""
        result = await db.database.contact_submissions.delete_one({"id": contact_id})
        return result.deleted_count > 0
    
    @staticmethod
    async def get_contact_stats() -> dict:
        """Get contact statistics"""
        pipeline = [
            {
                "$group": {
                    "_id": "$status",
                    "count": {"$sum": 1}
                }
            }
        ]
        
        status_counts = {}
        async for result in db.database.contact_submissions.aggregate(pipeline):
            status_counts[result["_id"]] = result["count"]
        
        # Get time-based stats
        now = datetime.utcnow()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_start = today_start - timedelta(days=7)
        month_start = today_start - timedelta(days=30)
        
        today_count = await db.database.contact_submissions.count_documents({
            "timestamp": {"$gte": today_start}
        })
        
        week_count = await db.database.contact_submissions.count_documents({
            "timestamp": {"$gte": week_start}
        })
        
        month_count = await db.database.contact_submissions.count_documents({
            "timestamp": {"$gte": month_start}
        })
        
        total_count = await db.database.contact_submissions.count_documents({})
        
        return {
            "total_contacts": total_count,
            "new_contacts": status_counts.get("new", 0),
            "contacted_contacts": status_counts.get("contacted", 0),
            "resolved_contacts": status_counts.get("resolved", 0),
            "today_contacts": today_count,
            "this_week_contacts": week_count,
            "this_month_contacts": month_count
        }

# Services Repository
class ServiceRepository:
    
    @staticmethod
    async def create_service(service_data: dict) -> dict:
        """Create a new service"""
        result = await db.database.services.insert_one(service_data)
        service_data["_id"] = str(result.inserted_id)
        return service_data
    
    @staticmethod
    async def get_services(active_only: bool = True) -> list:
        """Get all services"""
        query = {"active": True} if active_only else {}
        cursor = db.database.services.find(query).sort("order", 1)
        services = []
        async for service in cursor:
            service["_id"] = str(service["_id"])
            services.append(service)
        return services
    
    @staticmethod
    async def get_service_by_id(service_id: str) -> Optional[dict]:
        """Get service by ID"""
        service = await db.database.services.find_one({"id": service_id})
        if service:
            service["_id"] = str(service["_id"])
        return service
    
    @staticmethod
    async def get_service_by_type(service_type: str) -> Optional[dict]:
        """Get service by type"""
        service = await db.database.services.find_one({"service_type": service_type, "active": True})
        if service:
            service["_id"] = str(service["_id"])
        return service
    
    @staticmethod
    async def update_service(service_id: str, update_data: dict) -> bool:
        """Update service"""
        update_data["updated_at"] = datetime.utcnow()
        result = await db.database.services.update_one(
            {"id": service_id}, 
            {"$set": update_data}
        )
        return result.modified_count > 0
    
    @staticmethod
    async def delete_service(service_id: str) -> bool:
        """Delete service"""
        result = await db.database.services.delete_one({"id": service_id})
        return result.deleted_count > 0

# Admin Users Repository
class AdminRepository:
    
    @staticmethod
    async def create_admin(admin_data: dict) -> dict:
        """Create a new admin user"""
        result = await db.database.admin_users.insert_one(admin_data)
        admin_data["_id"] = str(result.inserted_id)
        return admin_data
    
    @staticmethod
    async def get_admin_by_username(username: str) -> Optional[dict]:
        """Get admin by username"""
        admin = await db.database.admin_users.find_one({"username": username, "active": True})
        if admin:
            admin["_id"] = str(admin["_id"])
        return admin
    
    @staticmethod
    async def get_admin_by_id(admin_id: str) -> Optional[dict]:
        """Get admin by ID"""
        admin = await db.database.admin_users.find_one({"id": admin_id, "active": True})
        if admin:
            admin["_id"] = str(admin["_id"])
        return admin
    
    @staticmethod
    async def update_last_login(admin_id: str) -> bool:
        """Update admin last login time"""
        result = await db.database.admin_users.update_one(
            {"id": admin_id},
            {"$set": {"last_login": datetime.utcnow()}}
        )
        return result.modified_count > 0

# Initialize default data
async def init_default_data():
    """Initialize default services and admin user"""
    try:
        # Check if services exist
        service_count = await db.database.services.count_documents({})
        if service_count == 0:
            # Create default services
            default_services = [
                {
                    "id": "sewage-service",
                    "service_type": "sewage",
                    "title_gr": "Αποχέτευση & Καθαρισμός",
                    "description_gr": "Καθαρισμός και συντήρηση αποχετευτικών συστημάτων, απόφραξη σωλήνων και δικτύων αποχέτευσης με σύγχρονο εξοπλισμό.",
                    "features": ["Απόφραξη σωλήνων", "Καθαρισμός φρεατίων", "Συντήρηση δικτύων"],
                    "availability": "24/7",
                    "response_time": "30 minutes",
                    "active": True,
                    "order": 1,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "id": "pumping-service",
                    "service_type": "pumping",
                    "title_gr": "Άντληση Νερού",
                    "description_gr": "Υπηρεσίες άντλησης νερού από υπόγεια, κελάρια, και πλημμυρισμένους χώρους με εξειδικευμένο εξοπλισμό υψηλής απόδοσης.",
                    "features": ["Άντληση από κελάρια", "Καθαρισμός πλημμυρών", "Έκτακτες παρεμβάσεις"],
                    "availability": "24/7",
                    "response_time": "15 minutes",
                    "active": True,
                    "order": 2,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                },
                {
                    "id": "waste-service",
                    "service_type": "waste",
                    "title_gr": "Μεταφορά Αποβλήτων",
                    "description_gr": "Ασφαλής και περιβαλλοντικά υπεύθυνη μεταφορά και διάθεση αποβλήτων σύμφωνα με τους κανονισμούς της Ελληνικής νομοθεσίας.",
                    "features": ["Υγρά απόβλητα", "Βιομηχανικά απόβλητα", "Νόμιμη διάθεση"],
                    "availability": "Business hours",
                    "response_time": "Same day",
                    "active": True,
                    "order": 3,
                    "created_at": datetime.utcnow(),
                    "updated_at": datetime.utcnow()
                }
            ]
            
            for service in default_services:
                await db.database.services.insert_one(service)
            
            logger.info("Default services created")
        
        # Check if admin user exists
        admin_count = await db.database.admin_users.count_documents({})
        if admin_count == 0:
            from passlib.context import CryptContext
            pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")
            
            # Create default admin user
            default_admin = {
                "id": "admin-1",
                "username": "admin",
                "email": "admin@lymattica.gr",
                "password_hash": pwd_context.hash("lymattica2024"),  # Change this in production
                "role": "admin",
                "created_at": datetime.utcnow(),
                "active": True
            }
            
            await db.database.admin_users.insert_one(default_admin)
            logger.info("Default admin user created (username: admin, password: lymattica2024)")
            
    except Exception as e:
        logger.error(f"Error initializing default data: {e}")

def get_database() -> AsyncIOMotorDatabase:
    """Get database instance"""
    return db.database