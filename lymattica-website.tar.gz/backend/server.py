from fastapi import FastAPI, APIRouter, Depends, HTTPException, status, Request
from fastapi.responses import JSONResponse
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from typing import List, Optional
from datetime import datetime, timedelta

# Import our models and services
from models import *
from database import (
    connect_to_mongo, close_mongo_connection, init_default_data,
    ContactRepository, ServiceRepository, AdminRepository
)
from auth import (
    authenticate_user, create_access_token, get_current_active_user, 
    get_admin_user, ACCESS_TOKEN_EXPIRE_MINUTES
)
from email_service import email_service
import uuid

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# Create the main app
app = FastAPI(
    title="Lymattica API",
    description="Backend API for Lymattica waste management services",
    version="1.0.0"
)

# Create API router
api_router = APIRouter(prefix="/api")

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Startup and shutdown events
@app.on_event("startup")
async def startup_event():
    await connect_to_mongo()
    await init_default_data()
    logger.info("Lymattica API started successfully")

@app.on_event("shutdown")
async def shutdown_event():
    await close_mongo_connection()
    logger.info("Lymattica API shutdown complete")

# Utility functions
def get_client_ip(request: Request) -> str:
    """Get client IP address"""
    return request.client.host

def get_user_agent(request: Request) -> str:
    """Get user agent"""
    return request.headers.get("user-agent", "Unknown")

# === CONTACT ENDPOINTS ===

@api_router.post("/contacts", response_model=SuccessResponse)
async def create_contact(
    contact_data: ContactSubmissionCreate,
    request: Request
):
    """Submit new contact form"""
    try:
        # Create contact submission
        contact_dict = contact_data.dict()
        contact_dict.update({
            "id": str(uuid.uuid4()),
            "timestamp": datetime.utcnow(),
            "status": ContactStatus.NEW,
            "ip_address": get_client_ip(request),
            "user_agent": get_user_agent(request)
        })
        
        # Save to database
        saved_contact = await ContactRepository.create_contact(contact_dict)
        
        # Send email notifications (non-blocking)
        try:
            await email_service.send_contact_notification(saved_contact)
            await email_service.send_customer_acknowledgment(saved_contact)
        except Exception as e:
            logger.warning(f"Email notification failed: {e}")
        
        return SuccessResponse(
            message="Το μήνυμά σας στάλθηκε επιτυχώς! Θα επικοινωνήσουμε μαζί σας σύντομα.",
            data={"contact_id": saved_contact["id"]}
        )
        
    except Exception as e:
        logger.error(f"Error creating contact: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Προέκυψε σφάλμα κατά την αποστολή του μηνύματος. Παρακαλώ δοκιμάστε ξανά."
        )

@api_router.get("/contacts", response_model=List[ContactSubmission])
async def get_contacts(
    skip: int = 0,
    limit: int = 50,
    status_filter: Optional[ContactStatus] = None,
    current_user: dict = Depends(get_current_active_user)
):
    """Get contact submissions (admin only)"""
    try:
        contacts = await ContactRepository.get_contacts(
            skip=skip, 
            limit=limit, 
            status=status_filter.value if status_filter else None
        )
        return [ContactSubmission(**contact) for contact in contacts]
    except Exception as e:
        logger.error(f"Error fetching contacts: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching contacts"
        )

@api_router.get("/contacts/{contact_id}", response_model=ContactSubmission)
async def get_contact(
    contact_id: str,
    current_user: dict = Depends(get_current_active_user)
):
    """Get specific contact (admin only)"""
    contact = await ContactRepository.get_contact_by_id(contact_id)
    if not contact:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found"
        )
    return ContactSubmission(**contact)

@api_router.put("/contacts/{contact_id}", response_model=SuccessResponse)
async def update_contact(
    contact_id: str,
    update_data: ContactSubmissionUpdate,
    current_user: dict = Depends(get_current_active_user)
):
    """Update contact status/notes (admin only)"""
    success = await ContactRepository.update_contact(
        contact_id, 
        update_data.dict(exclude_unset=True)
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found"
        )
    
    return SuccessResponse(message="Contact updated successfully")

@api_router.delete("/contacts/{contact_id}", response_model=SuccessResponse)
async def delete_contact(
    contact_id: str,
    current_user: dict = Depends(get_admin_user)
):
    """Delete contact (admin only)"""
    success = await ContactRepository.delete_contact(contact_id)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Contact not found"
        )
    
    return SuccessResponse(message="Contact deleted successfully")

# === SERVICE ENDPOINTS ===

@api_router.get("/services", response_model=List[Service])
async def get_services(active_only: bool = True):
    """Get all services"""
    try:
        services = await ServiceRepository.get_services(active_only=active_only)
        return [Service(**service) for service in services]
    except Exception as e:
        logger.error(f"Error fetching services: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching services"
        )

@api_router.get("/services/{service_type}", response_model=Service)
async def get_service_by_type(service_type: ServiceType):
    """Get service by type"""
    service = await ServiceRepository.get_service_by_type(service_type.value)
    if not service:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Service not found"
        )
    return Service(**service)

@api_router.post("/services", response_model=SuccessResponse)
async def create_service(
    service_data: ServiceCreate,
    current_user: dict = Depends(get_admin_user)
):
    """Create new service (admin only)"""
    try:
        service_dict = service_data.dict()
        service_dict.update({
            "id": str(uuid.uuid4()),
            "created_at": datetime.utcnow(),
            "updated_at": datetime.utcnow()
        })
        
        saved_service = await ServiceRepository.create_service(service_dict)
        return SuccessResponse(
            message="Service created successfully",
            data={"service_id": saved_service["id"]}
        )
    except Exception as e:
        logger.error(f"Error creating service: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error creating service"
        )

@api_router.put("/services/{service_id}", response_model=SuccessResponse)
async def update_service(
    service_id: str,
    update_data: ServiceUpdate,
    current_user: dict = Depends(get_admin_user)
):
    """Update service (admin only)"""
    success = await ServiceRepository.update_service(
        service_id,
        update_data.dict(exclude_unset=True)
    )
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Service not found"
        )
    
    return SuccessResponse(message="Service updated successfully")

@api_router.delete("/services/{service_id}", response_model=SuccessResponse)
async def delete_service(
    service_id: str,
    current_user: dict = Depends(get_admin_user)
):
    """Delete service (admin only)"""
    success = await ServiceRepository.delete_service(service_id)
    
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Service not found"
        )
    
    return SuccessResponse(message="Service deleted successfully")

# === AUTHENTICATION ENDPOINTS ===

@api_router.post("/auth/login", response_model=Token)
async def login(credentials: AdminUserLogin):
    """Admin login"""
    user = await authenticate_user(credentials.username, credentials.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    # Update last login
    await AdminRepository.update_last_login(user["id"])
    
    # Create access token
    access_token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = create_access_token(
        data={
            "sub": user["username"], 
            "user_id": user["id"],
            "role": user["role"]
        },
        expires_delta=access_token_expires
    )
    
    return Token(
        access_token=access_token,
        expires_in=ACCESS_TOKEN_EXPIRE_MINUTES * 60
    )

@api_router.get("/auth/me", response_model=AdminUserResponse)
async def get_current_user_info(current_user: dict = Depends(get_current_active_user)):
    """Get current user info"""
    return AdminUserResponse(
        id=current_user["id"],
        username=current_user["username"],
        email=current_user["email"],
        role=current_user["role"],
        created_at=current_user["created_at"],
        last_login=current_user.get("last_login")
    )

@api_router.post("/auth/logout", response_model=SuccessResponse)
async def logout(current_user: dict = Depends(get_current_active_user)):
    """Admin logout (client should delete token)"""
    return SuccessResponse(message="Logged out successfully")

# === STATISTICS ENDPOINTS ===

@api_router.get("/stats/contacts", response_model=ContactStats)
async def get_contact_stats(current_user: dict = Depends(get_current_active_user)):
    """Get contact statistics"""
    try:
        stats = await ContactRepository.get_contact_stats()
        return ContactStats(**stats)
    except Exception as e:
        logger.error(f"Error fetching contact stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching statistics"
        )

@api_router.get("/stats/dashboard", response_model=DashboardStats)
async def get_dashboard_stats(current_user: dict = Depends(get_current_active_user)):
    """Get dashboard statistics"""
    try:
        # Get contact stats
        contact_stats = await ContactRepository.get_contact_stats()
        
        # Get recent contacts
        recent_contacts = await ContactRepository.get_contacts(skip=0, limit=10)
        
        # Get service stats
        services = await ServiceRepository.get_services(active_only=False)
        service_stats = {
            "total_services": len(services),
            "active_services": len([s for s in services if s.get("active", True)]),
            "service_breakdown": {}
        }
        
        return DashboardStats(
            contact_stats=ContactStats(**contact_stats),
            service_stats=ServiceStats(**service_stats),
            recent_contacts=[ContactSubmission(**c) for c in recent_contacts]
        )
    except Exception as e:
        logger.error(f"Error fetching dashboard stats: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Error fetching dashboard statistics"
        )

# === HEALTH CHECK ===

@api_router.get("/health")
async def health_check():
    """System health check"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow(),
        "service": "Lymattica API",
        "version": "1.0.0"
    }

# Basic root endpoint
@api_router.get("/")
async def root():
    """API root endpoint"""
    return {
        "message": "Lymattica API",
        "version": "1.0.0",
        "docs": "/docs",
        "health": "/api/health"
    }

# Include the router in the main app
app.include_router(api_router)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global exception handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    """Global exception handler"""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal server error"}
    )
