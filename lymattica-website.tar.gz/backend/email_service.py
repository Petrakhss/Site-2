import smtplib
import logging
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from typing import Optional
import os
from datetime import datetime

logger = logging.getLogger(__name__)

class EmailService:
    def __init__(self):
        self.smtp_server = os.getenv("SMTP_SERVER", "smtp.gmail.com")
        self.smtp_port = int(os.getenv("SMTP_PORT", "587"))
        self.smtp_username = os.getenv("SMTP_USERNAME", "")
        self.smtp_password = os.getenv("SMTP_PASSWORD", "")
        self.from_email = os.getenv("FROM_EMAIL", "info@lymattica.gr")
        self.from_name = os.getenv("FROM_NAME", "Lymattica")
        self.admin_email = os.getenv("ADMIN_EMAIL", "admin@lymattica.gr")
    
    def _create_smtp_connection(self):
        """Create SMTP connection"""
        try:
            server = smtplib.SMTP(self.smtp_server, self.smtp_port)
            server.starttls()
            
            if self.smtp_username and self.smtp_password:
                server.login(self.smtp_username, self.smtp_password)
            
            return server
        except Exception as e:
            logger.error(f"Failed to create SMTP connection: {e}")
            return None
    
    async def send_contact_notification(self, contact_data: dict) -> bool:
        """Send notification email when new contact is received"""
        if not self.smtp_username or not self.smtp_password:
            logger.warning("Email credentials not configured, skipping email notification")
            return False
        
        try:
            server = self._create_smtp_connection()
            if not server:
                return False
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = f"{self.from_name} <{self.from_email}>"
            msg['To'] = self.admin_email
            msg['Subject'] = "Νέο Μήνυμα από Lymattica.gr"
            
            # Email body in Greek
            service_names = {
                "sewage": "Αποχέτευση & Καθαρισμός",
                "pumping": "Άντληση Νερού", 
                "waste": "Μεταφορά Αποβλήτων",
                "emergency": "Έκτακτη Ανάγκη"
            }
            
            service_text = service_names.get(contact_data.get('service', ''), 'Δεν επιλέχθηκε υπηρεσία')
            timestamp = contact_data.get('timestamp', datetime.utcnow())
            
            body = f"""
Νέο μήνυμα επικοινωνίας από το website της Lymattica:

📝 ΣΤΟΙΧΕΙΑ ΠΕΛΑΤΗ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Όνομα: {contact_data.get('name', 'Δεν δόθηκε')}
Email: {contact_data.get('email', 'Δεν δόθηκε')}
Τηλέφωνο: {contact_data.get('phone', 'Δεν δόθηκε')}
Υπηρεσία: {service_text}
Ημερομηνία: {timestamp.strftime('%d/%m/%Y %H:%M')}

💬 ΜΗΝΥΜΑ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
{contact_data.get('message', 'Κενό μήνυμα')}

📊 ΤΕΧΝΙΚΑ ΣΤΟΙΧΕΙΑ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
ID Μηνύματος: {contact_data.get('id', 'N/A')}
IP Address: {contact_data.get('ip_address', 'N/A')}
User Agent: {contact_data.get('user_agent', 'N/A')}

⚡ ΕΝΕΡΓΕΙΕΣ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
📞 Κλήση: {contact_data.get('phone', 'N/A')}
📧 Email: {contact_data.get('email', 'N/A')}

Παρακαλώ επικοινωνήστε με τον πελάτη το συντομότερο δυνατό.

--
Lymattica - Επαγγελματικές Υπηρεσίες Διαχείρισης Αποβλήτων
https://lymattica.gr | 210 123 4567
            """
            
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            text = msg.as_string()
            server.sendmail(self.from_email, self.admin_email, text)
            server.quit()
            
            logger.info(f"Contact notification email sent for: {contact_data.get('name', 'Unknown')}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send contact notification email: {e}")
            return False
    
    async def send_customer_acknowledgment(self, contact_data: dict) -> bool:
        """Send acknowledgment email to customer"""
        if not self.smtp_username or not self.smtp_password:
            return False
        
        try:
            server = self._create_smtp_connection()
            if not server:
                return False
            
            customer_email = contact_data.get('email')
            if not customer_email:
                return False
            
            # Create message
            msg = MIMEMultipart()
            msg['From'] = f"{self.from_name} <{self.from_email}>"
            msg['To'] = customer_email
            msg['Subject'] = "Λάβαμε το μήνυμά σας - Lymattica"
            
            customer_name = contact_data.get('name', 'Αγαπητέ/ή πελάτη')
            
            body = f"""
Αγαπητέ/ή {customer_name},

Σας ευχαριστούμε για την επικοινωνία σας με την Lymattica!

📨 ΕΠΙΒΕΒΑΙΩΣΗ ΜΗΝΥΜΑΤΟΣ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Το μήνυμά σας έχει παραληφθεί και θα επικοινωνήσουμε μαζί σας 
το συντομότερο δυνατό.

⏰ ΧΡΟΝΟΣ ΑΝΤΑΠΟΚΡΙΣΗΣ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Κανονικές ώρες: Εντός 2 ωρών (8:00-18:00)
• Έκτακτες ανάγκες: 15-30 λεπτά (24/7)

📞 ΕΚΤΑΚΤΗ ΑΝΑΓΚΗ;
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Για επείγουσες περιπτώσεις καλέστε άμεσα:
🔥 Έκτακτη Γραμμή: 694 567 8901
📞 Κεντρικό: 210 123 4567

✅ ΟΙ ΥΠΗΡΕΣΙΕΣ ΜΑΣ:
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Αποχέτευση & Καθαρισμός (24/7)
• Άντληση Νερού (Άμεση ανταπόκριση)
• Μεταφορά Αποβλήτων (Νόμιμη διάθεση)

Ευχαριστούμε για την εμπιστοσύνη σας!

--
Με εκτίμηση,
Η Ομάδα της Lymattica

📧 info@lymattica.gr
📞 210 123 4567 | 🚨 694 567 8901
📍 Αθήνα, Αττική
🌐 https://lymattica.gr
            """
            
            msg.attach(MIMEText(body, 'plain', 'utf-8'))
            
            text = msg.as_string()
            server.sendmail(self.from_email, customer_email, text)
            server.quit()
            
            logger.info(f"Customer acknowledgment email sent to: {customer_email}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send customer acknowledgment email: {e}")
            return False

# Global email service instance
email_service = EmailService()