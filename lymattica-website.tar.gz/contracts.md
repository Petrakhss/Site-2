# Lymattica Backend Integration Contracts

## Overview
This document outlines the API contracts and integration plan for the Lymattica waste transportation website, transitioning from mock data to full backend functionality.

## Current Mock Data (to be replaced)
- Contact form submissions in localStorage
- Static service information
- Mock company statistics
- Static Greek content

## Backend Implementation Plan

### 1. Database Models

#### ContactSubmission Model
```python
{
  "id": ObjectId,
  "name": str,
  "email": str, 
  "phone": str,
  "service": str, # "sewage", "pumping", "waste", "emergency"
  "message": str,
  "timestamp": datetime,
  "status": str, # "new", "contacted", "resolved"
  "admin_notes": str,
  "ip_address": str,
  "user_agent": str
}
```

#### Service Model (for dynamic content)
```python
{
  "id": ObjectId,
  "service_type": str, # "sewage", "pumping", "waste"
  "title_gr": str,
  "description_gr": str,
  "features": [str],
  "pricing_info": str,
  "availability": str,
  "response_time": str,
  "active": bool,
  "order": int
}
```

#### Admin User Model
```python
{
  "id": ObjectId,
  "username": str,
  "email": str,
  "password_hash": str,
  "role": str, # "admin", "operator"
  "created_at": datetime,
  "last_login": datetime
}
```

### 2. API Endpoints

#### Contact Management
- `POST /api/contacts` - Submit new contact form
- `GET /api/contacts` - List all contacts (admin only)  
- `GET /api/contacts/{id}` - Get specific contact (admin only)
- `PUT /api/contacts/{id}` - Update contact status/notes (admin only)
- `DELETE /api/contacts/{id}` - Delete contact (admin only)

#### Services Management
- `GET /api/services` - Get all active services
- `GET /api/services/{type}` - Get specific service details
- `POST /api/services` - Create service (admin only)
- `PUT /api/services/{id}` - Update service (admin only)
- `DELETE /api/services/{id}` - Delete service (admin only)

#### Admin Authentication
- `POST /api/auth/login` - Admin login
- `POST /api/auth/logout` - Admin logout
- `GET /api/auth/me` - Get current admin user
- `POST /api/auth/refresh` - Refresh token

#### Statistics/Dashboard
- `GET /api/stats/contacts` - Contact statistics
- `GET /api/stats/services` - Service usage stats
- `GET /api/health` - System health check

### 3. Email Notification System

#### SMTP Configuration
- Use environment variables for email settings
- Send notifications for new contact submissions
- Email templates in Greek for professional communication

#### Email Types
1. **New Contact Notification** (to admin)
   - Subject: "Νέο Μήνυμα από Lymattica.gr"
   - Contains all contact details and message
   
2. **Auto-reply to Customer** (optional)
   - Subject: "Λάβαμε το μήνυμά σας - Lymattica"
   - Professional acknowledgment in Greek

### 4. Frontend Integration Changes

#### Remove Mock Dependencies
- Replace `mock.js` with actual API calls
- Remove localStorage contact storage
- Update form submission to use backend API

#### New Routes to Add
- `/services` - Detailed services page
- `/admin` - Admin dashboard (protected)
- `/admin/contacts` - Contact management
- `/admin/services` - Service management

#### API Integration Points
1. **Contact Form** (`Contact.jsx`)
   - Replace localStorage with POST /api/contacts
   - Add loading states and error handling
   - Show success confirmation

2. **Services Display** (`Services.jsx`)
   - Fetch from GET /api/services
   - Dynamic content rendering

3. **New Services Page** (`pages/Services.jsx`)
   - Detailed service information
   - Quality assurance details
   - B2B contract information

### 5. Admin Panel Features

#### Dashboard Overview
- Total contacts received
- Recent submissions
- Service inquiry breakdown
- Response time statistics

#### Contact Management
- List view with sorting/filtering
- Status updates (new/contacted/resolved)
- Add internal notes
- Export to CSV
- Quick actions (call, email)

#### Service Management
- Update service descriptions
- Modify pricing information
- Control service availability
- Reorder services display

### 6. New Services Page Structure

#### Sections to Include
1. **Service Quality Standards**
   - Certified technicians
   - Modern equipment
   - Environmental compliance
   - 24/7 availability

2. **Individual Service Details**
   - Sewage & Cleaning (detailed procedures)
   - Water Pumping (equipment specifications)  
   - Waste Transport (including B2B contracts)

3. **Business Services**
   - Facility maintenance contracts
   - Regular service schedules
   - Commercial waste management
   - Industrial cleaning services

4. **Quality Assurance**
   - Insurance coverage
   - Professional certifications
   - Emergency response protocols
   - Customer satisfaction guarantee

### 7. Security Considerations

#### Authentication
- JWT tokens for admin sessions
- Password hashing with bcrypt
- Session timeout handling
- Protected route middleware

#### Data Protection
- Input validation and sanitization
- Rate limiting on contact submissions
- CORS configuration
- Environment variable security

## Implementation Order

1. **Backend Models & Database** (Priority 1)
2. **Contact API Endpoints** (Priority 1)
3. **Email Notification System** (Priority 2)
4. **New Services Page** (Priority 2)
5. **Admin Authentication** (Priority 3)
6. **Admin Panel UI** (Priority 3)
7. **Frontend Integration** (Priority 1)
8. **Testing & Validation** (Priority 1)

## Testing Protocol

1. Test contact form submissions
2. Verify email notifications
3. Test admin authentication
4. Validate data persistence
5. Check responsive design on new pages
6. Verify all Greek translations
7. Test error handling scenarios

This contract ensures smooth transition from mock data to full backend functionality while maintaining the professional quality of the Lymattica website.